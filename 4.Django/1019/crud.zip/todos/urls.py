from django.urls import path

app_name = 'todos'
urlpatterns = [
    
]
